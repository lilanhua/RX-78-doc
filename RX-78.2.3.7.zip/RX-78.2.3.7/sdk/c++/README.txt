libRX78-vcXXX-mt-s-x32-X_X 是静态库，使用静态库需要设置项目
  在 项目属性 -> C/C++ -> 预处理器 -> 预处理器定义 中添加 RX78_STATIC_LIB

RX78-vcXXX-mt-s-x32-X_X 是动态库，编译生成的程序需要带上 RX78-vcXXX-mt-s-x32-X_X.dll
