﻿#include <iostream>
#include "RX-78.h"

using namespace std;
using namespace RX78;

int main()
{
#if _MSC_VER >= 1900
  // VS2015 及以上版本用下面的方法
  Device device_greater_than_2015;
  cout << device_greater_than_2015.Open(L"XXXX-XXXX-XXXX") << endl;
  cout << device_greater_than_2015.KeyPress(VirtualKeyCode::kOSLeft) << endl;
#endif

  // VS2015 以前的版本只能用下面的方法（VS2015 及以上版本也可以）
  Device* device_less_than_2015 = Device::New();  // 创建
  cout << device_less_than_2015->Open(L"XXXX-XXXX-XXXX") << endl;
  cout << device_less_than_2015->KeyPress(VirtualKeyCode::kOSLeft) << endl;
  Device::Destroy(device_less_than_2015);  // 销毁
}
