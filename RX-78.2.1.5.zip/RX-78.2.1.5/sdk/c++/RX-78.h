﻿#pragma once
// Version: 2.1.5

#include <mutex>
#include <string>
#include <random>
#include <ostream>

#include <cstdint>

#include <Windows.h>

#if RX78CPP_EXPORTS
#define API(...) _declspec(dllexport) __VA_ARGS__ _stdcall
#else
#define API(...) _declspec(dllimport) __VA_ARGS__ _stdcall
#endif

namespace RX78
{
  const size_t kDeviceNameLengthMax = 29;
  const size_t kVerifiedDataSizeMax = 22;
  const size_t kVendorNameLengthMax = 18;

  enum class Result: uint32_t
  {
    kSuccess,
    kSystemError,
    kDeviceNotFound,
    kInvalidResolutionValue,
    kTimeout,
    kInvalidTimeoutValue,
    kCursorUnreset,

    kInvalidKeyValue  = 0x0100,
    kKeyFull          = 0x0200,
    kNotModified      = 0x0300,
    kInvalidSize      = 0x0400,
    kInvalidPkgType   = 0x0500,
    kConfigError      = 0x0600,
    kVerifyFailed     = 0x0700,
    kMethodNotAllowed = 0x0800,
    kInvalidMouseMode = 0x0900,

    kInvalidResult = 0xFFFFFFFF,

  };

  // 将返回结果代码转为字符串。
  API(const char *) ResultToStr(Result result);

  inline std::ostream& operator<<(std::ostream& stream, const RX78::Result result)
  {
    return stream << ResultToStr(result);
  }

  enum class VirtualKeyCode : uint8_t
  {
    kInvalid = 0,

    kBackspace = 0x08,
    kTab,

    kEnter = 0x0D,

    kShift = 0x10,
    kControl,
    kAlt,
    kPause,
    kCapsLock,

    kEscape = 0x1B,

    kSpace = 0x20,
    kPageUp,
    kPageDown,
    kEnd,
    kHome,

    kArrowLeft,   /* ← */
    kArrowUp,     /* ↑ */
    kArrowRight,  /* → */
    kArrowDown,   /* ↓ */

    kPrintScreen = 0x2C,
    kInsert,
    kDelete,

    kDigit0 = '0', kDigit1,
    kDigit2, kDigit3, kDigit4, kDigit5,
    kDigit6, kDigit7, kDigit8, kDigit9,

    kKeyA = 'A',  kKeyB,
    kKeyC, kKeyD, kKeyE, kKeyF, kKeyG, kKeyH,
    kKeyI, kKeyJ, kKeyK, kKeyL, kKeyM, kKeyN,
    kKeyO, kKeyP, kKeyQ, kKeyR, kKeyS, kKeyT,
    kKeyU, kKeyV, kKeyW, kKeyX, kKeyY, kKeyZ,

    kOSLeft,
    kOSRight,
    kContextMenu,  /* ≣ */

    kNumpad0 = 0x60, kNumpad1,
    kNumpad2, kNumpad3, kNumpad4, kNumpad5,
    kNumpad6, kNumpad7, kNumpad8, kNumpad9,

    kNumpadMultiply,  /* * */
    kNumpadAdd,       /* + */
    kNumpadEnter,
    kNumpadSubtract,  /* - */
    kNumpadDecimal,   /* . */
    kNumpadDivide,    /* / */

    kF1, kF2, kF3, kF4, kF5, kF6,
    kF7, kF8, kF9, kF10, kF11, kF12,

    kNumLock = 0x90,
    kScrollLock,

    kShiftLeft = 0xA0,
    kShiftRight,
    kControlLeft,
    kControlRight,
    VkAltLeft,
    kAltRight,

    kSemicolon = 0xBA,    /* ; */
    kEqual,               /* = */
    kComma,               /* , */
    KMinus,               /* - */
    kPeriod,              /* . */
    kSlash,               /* / */
    kBackquote,           /* ` */

    kBracketLeft = 0xDB,  /* [ */
    kBackslash,           /* \ */
    kBracketRight,        /* ] */
    kQuote,               /* ' */
  };

  enum class Led : uint8_t
  {
    kNumLock    = 0b00001,
    kCapsLock   = 0b00010,
    kScrollLock = 0b00100,
    kCompose    = 0b01000,
    kKana       = 0b10000,
  };

  enum class Button : uint8_t
  {
    kLeft, kRight, kMiddle,
  };

  enum class MouseMode : uint8_t
  {
    kRelative,  // 相对
    kAbsolute,  // 绝对
    kBoth       // 相对+绝对
  };

  enum class DeviceType : uint8_t
  {
    k1 = 1,  // 1 头设备
    k2,      // 2 头设备
    k3       // 3 头设备
  };

  template <typename T>
  struct Range
  {
    T from;
    T to;
  };

  template <typename T>
  struct Offset
  {
    T x;
    T y;
  };

  class Device
  {
  public:
    API() Device();
    virtual API() ~Device();

    static API(Device*) New();
    static API(void) Destroy(Device* device);

  //                                                                     //
  // ----------------------------- 控制 API ----------------------------- //
  //                                                                     //

    // 打开设备，其他操作都需要打开成功后才能进行。
    // serial_number  : 形如 XXXX-XXXX-XXXX，包括横杠，不包括方括号，字母全部为大写。
    // target_resolution_x : 目标屏幕宽度，默认值为当前屏幕宽度。
    // target_resolution_y : 目标屏幕高度，默认值为当前屏幕高度。
    // device_type: 兼容旧版本硬件，新版本不填。可选值为： DeviceType::k1（1 头）、DeviceType::k2（2 头）、DeviceType::k3（3 头）。
    // mouse_mode: 兼容旧版本硬件，新版本不填。可选值为：MouseMode::kRelative（3 头）、MouseMode::kBoth（1 头、2 头）。
    API(Result) Open(const std::wstring &serial_number,
      int16_t target_resolution_x=GetSystemMetrics(SM_CXSCREEN),
      int16_t target_resolution_y=GetSystemMetrics(SM_CYSCREEN),
      DeviceType device_type=static_cast<DeviceType>(-1), MouseMode mouse_mode=static_cast<MouseMode>(-1));
    API(Result) Open(const wchar_t *serial_number,
      int16_t target_resolution_x=GetSystemMetrics(SM_CXSCREEN),
      int16_t target_resolution_y=GetSystemMetrics(SM_CYSCREEN),
      DeviceType device_type=static_cast<DeviceType>(-1), MouseMode mouse_mode=static_cast<MouseMode>(-1));

    API(Result) Open(uint16_t vendor_ID, uint16_t product_ID,
      int16_t target_resolution_x=GetSystemMetrics(SM_CXSCREEN),
      int16_t target_resolution_y=GetSystemMetrics(SM_CYSCREEN),
      DeviceType device_type=static_cast<DeviceType>(-1), MouseMode mouse_mode=static_cast<MouseMode>(-1));

    // 关闭设备。
    // 对象销毁时会自动调用此方法关闭设备。
    API(Result) Close();

    // 重启整个设备。
    // 可在配置设备id、厂商id、产品id后重启设备，以刷新信息。
    // 成功后内部会调用 Close。
    API(Result) Restart();

    // 重启鼠标端，只有 3 头设备有效。
    API(Result) RestartMouse();

    // 重启键盘端，只有 3 头设备有效。
    API(Result) RestartKeyboard();

    // 重启控制端，只有 2 头或 3 头设备有效。
    API(Result) RestartMaster();

    // 重启被控端，只有 2 头或 3 头设备有效。
    API(Result) RestartWorker();

  //                                                                     //
  // ----------------------------- 配置 API ----------------------------- //
  //                                                                     //

    // ------------------ 厂商 ID --------------------- //
    // 配置整个设备 vendor ID。
    // 2 头和 3 头设备将同时设置控制端和被控端的 ID。
    // 重新插入设备或调用 Restart 后生效。
    API(Result) ConfigVendorID(uint16_t vendor_ID);

    // 配置鼠标 vendor ID。
    API(Result) ConfigMouseVendorID(uint16_t vendor_ID);

    // 配置键盘 vendor ID。
    API(Result) ConfigKeyboardVendorID(uint16_t vendor_ID);

    // 配置控制端 vendor ID。
    API(Result) ConfigMasterVendorID(uint16_t vendor_ID);

    // 配置被控端 vendor ID。
    API(Result) ConfigWorkerVendorID(uint16_t vendor_ID);

    // ------------------ 产品 ID --------------------- //
    // 配置整个设备 product ID
    // 2 头和 3 头设备将同时设置控制端和被控端的 ID。
    // 重新插入设备或调用 Restart 后生效。
    API(Result) ConfigProductID(uint16_t product_ID);

    // 配置鼠标 product ID。
    API(Result) ConfigMouseProductID(uint16_t product_ID);

    // 配置鼠标 product ID。

    API(Result) ConfigKeyboardProductID(uint16_t product_ID);
    // 配置鼠标 product ID。

    API(Result) ConfigMasterProductID(uint16_t product_ID);
    // 配置鼠标 product ID。

    API(Result) ConfigWorkerProductID(uint16_t product_ID);

    // ------------------ 名称 --------------------- //
    // 配置整个设备名称。
    // 2 头和 3 头设备将同时设置控制端和被控端的名称。
    // 不包括唯一标识部分，重新插入设备或调用 Restart 后生效。
    // 名称长度要求大于 0 小于等于 29，一个中文符号也算一个长度。
    API(Result) ConfigName(const std::wstring &name);
    API(Result) ConfigName(const wchar_t *name);

    // 配置鼠标名。
    API(Result) ConfigMouseName(const std::wstring &name);
    API(Result) ConfigMouseName(const wchar_t *name);

    // 配置键盘名。
    API(Result) ConfigKeyboardName(const std::wstring &name);
    API(Result) ConfigKeyboardName(const wchar_t *name);

    // 配置控制端名。
    API(Result) ConfigMasterName(const std::wstring &name);
    API(Result) ConfigMasterName(const wchar_t *name);

    // 配置被控端名。
    API(Result) ConfigWorkerName(const std::wstring &name);
    API(Result) ConfigWorkerName(const wchar_t *name);

    // ------------------ 修订号 --------------------- //
    // 配置修订号
    API(Result) ConfigVersion(uint16_t version);

    // 配置控制端修订号
    API(Result) ConfigMasterVersion(uint16_t version);

    // 配置被控端修订号
    API(Result) ConfigWorkerVersion(uint16_t version);

    // 配置鼠标修订号
    API(Result) ConfigMouseVersion(uint16_t version);

    // 配置键盘修订号
    API(Result) ConfigKeyboardVersion(uint16_t version);

    // ------------------ 配置制造商 --------------------- //
    // 配置制造商
    // 长度要求大于等于 0 小于等于 18。
    API(Result) ConfigVendor(const std::wstring &vendor);
    API(Result) ConfigVendor(const wchar_t *vendor);

    // 配置制造商
    API(Result) ConfigMasterVendor(const std::wstring &vendor);
    API(Result) ConfigMasterVendor(const wchar_t *vendor);

    // 配置制造商
    API(Result) ConfigWorkerVendor(const std::wstring &vendor);
    API(Result) ConfigWorkerVendor(const wchar_t *vendor);

    // 配置制造商
    API(Result) ConfigMouseVendor(const std::wstring &vendor);
    API(Result) ConfigMouseVendor(const wchar_t *vendor);

    // 配置制造商
    API(Result) ConfigKeyboardVendor(const std::wstring &vendor);
    API(Result) ConfigKeyboardVendor(const wchar_t *vendor);

    // ------------------ 鼠标模式 --------------------- //
    // 配置鼠标模式，需要重启。
    API(Result) ConfigMouseMode(MouseMode mode);

    // 取当前鼠标模式。
    API(Result) GetMouseMode(MouseMode &mode);

  //                                                                     //
  // ----------------------------- 验证 API ----------------------------- //
  //                                                                     //

    // 将数据存储到设备中。
    // 只能用 VerifyData 验证是否一致，不可读取。
    // 长度要求大于 0 小于等于 22。
    API(Result) ConfigData(const std::string &data);
    API(Result) ConfigData(const char *data, size_t size);

    // 验证用 ConfigData 存储到设备中的数据。
    API(Result) VerifyData(const std::string &data);
    API(Result) VerifyData(const char *data, size_t size);


  //                                                                     //
  // ----------------------------- 键盘 API ----------------------------- //
  //                                                                     //

    // 按下后不弹起按键。
    API(Result) KeyDown(VirtualKeyCode virtual_key_code);

    // 弹起按键。
    API(Result) KeyUp(VirtualKeyCode virtual_key_code);

    // 按下后弹起按键，若按下或弹起过程中失败，则提前返回。
    // virtual_key_code       : 要按下弹起的键的虚拟键码。
    // sleep_after_down_range : 按下键盘后随机延迟的范围，默认为 { 50, 80 }，即大于等于 50 ms，小于等于 80 ms。
    // sleep_after_down_range : 弹起键盘后随机延迟的范围，默认为 { 150, 600 }，即大于等于 150 ms，小于等于 600 ms。
    API(Result) KeyPress(VirtualKeyCode virtual_key_code,
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 150, 600 });

    // 打字
    // 支持中英文。
    API(Result) Type(const char *str,
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 150, 600 });
    API(Result) Type(const std::string str,
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 150, 600 });

    // 打字
    // 支持中英文。一些输入框使用 Type 乱码，尝试使用此方法。
    API(Result) TypeW(const wchar_t *str,
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 150, 600 });
    API(Result) TypeW(const std::wstring str,
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 150, 600 });

    // 判断按键是否为按下状态。
    API(Result) GetKeyState(VirtualKeyCode virtual_key_code, bool &is_downed);

    // 释放所有按键。
    API(Result) ReleaseAllKeys();

    // 判断键盘状态 LED 灯是否点亮。
    API(Result) GetLedState(Led led, bool &is_lit);


  //                                                                     //
  // ----------------------------- 鼠标 API ----------------------------- //
  //                                                                     //

    // 取鼠标坐标
    API(Result) GetPos(uint16_t *x, uint16_t *y);

    // 重置光标
    API(Result) ResetCursor();

    // 按下鼠标左键。
    API(Result) LeftDown();

    // 弹起鼠标左键。
    API(Result) LeftUp();

    // 鼠标左键按下后弹起。
    API(Result) LeftClick(
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 500, 900 });

    // 双击鼠标左键。
    API(Result) LeftDoubleClick(
      const Range<uint32_t> &sleep_after_first_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_first_up_range={ 60, 110 },
      const Range<uint32_t> &sleep_after_second_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_second_up_range={ 500, 900 });

    // 按下鼠标右键。
    API(Result) RightDown();

    // 弹起鼠标右键。
    API(Result) RightUp();

    // 鼠标右键按下后弹起。
    API(Result) RightClick(
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 500, 900 });

    // 双击鼠标右键。
    API(Result) RightDoubleClick(
      const Range<uint32_t> &sleep_after_first_down_range= { 50, 80 },
      const Range<uint32_t> &sleep_after_first_up_range={ 60, 110 },
      const Range<uint32_t> &sleep_after_second_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_second_up_range={ 500, 900 });

    // 按下鼠标中键。
    API(Result) MiddleDown();

    // 弹起鼠标中键。
    API(Result) MiddleUp();

    // 鼠标中键按下后弹起。
    API(Result) MiddleClick(
      const Range<uint32_t> &sleep_after_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_up_range={ 500, 900 });

    // 双击鼠标中键。
    API(Result) MiddleDoubleClick(
      const Range<uint32_t> &sleep_after_first_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_first_up_range={ 60, 110 },
      const Range<uint32_t> &sleep_after_second_down_range={ 50, 80 },
      const Range<uint32_t> &sleep_after_second_up_range={ 500, 900 });

    // 弹起左键、右键和中键。
    API(Result) ReleaseAllButtons();

    // 取鼠标按键状态。
    API(Result) GetButtonState(Button button, bool &is_downed);

    // 滚动鼠标滑轮。
    // value : 向上为正，向下为负。
    API(Result) Scroll(int16_t value);

    // 以当前鼠标位置为基点，移动鼠标。
    // x : x 轴移动距离
    // y : y 轴移动距离
    API(Result) ToRel(int16_t x, int16_t y);

    // 移动鼠标到指定坐标。
    // 需要先设置被控机器的分辨率，否则返回 Result::kInvalidResolutionValue。
    API(Result) ToAbs(int16_t x, int16_t y);

    // 使用数学方程模拟移动轨迹将鼠标移动到相对坐标。
    // 此方法为相对移动。详细见文档。
    API(Result) MoveRel(int16_t x, int16_t y,
      double sample_rate = 0.2,
      uint32_t sleep = 16,
      const Range<double> &a1={ 1, 3 }, const Range<double> &b1={ 0.001, 0.08 },
      const Range<double> &a2={ 0.5, 2 }, const Range<double> &b2={ 0.001, 0.06 },
      const Range<double> &p1_x={ 0.001, 1 }, const Range<double> &p1_y={ 0.001, 1 },
      const Range<double> &p2_x={ 0.001, 1 }, const Range<double> &p2_y={ 0.001, 1 }
    );

    // 使用数学方程模拟移动轨迹将鼠标移动到绝对坐标。
    // 此方法为相对移动。详细见文档。
    API(Result) MoveAbs(int16_t x, int16_t y,
      double sample_rate = 0.2,
      uint32_t sleep = 16,
      const Range<double> &a1={ 1, 3 }, const Range<double> &b1={ 0.001, 0.08 },
      const Range<double> &a2={ 0.5, 2 }, const Range<double> &b2={ 0.001, 0.06 },
      const Range<double> &p1_x={ 0.001, 1 }, const Range<double> &p1_y={ 0.001, 1 },
      const Range<double> &p2_x={ 0.001, 1 }, const Range<double> &p2_y={ 0.001, 1 }
    );

    // 根据传入的轨迹数据进行移动，此方法为相对移动。
    // offsets : 偏移列表。
    // size    : 偏移列表大小，轨迹数据大小，如：{ {0, 1}, {1, 3}, {2, 3} }，大小为 3。
    // sleep   : 每个点之间的延迟。
    API(Result) Trace(const int16_t offsets[][2], size_t size, uint32_t sleep=16);

    // 根据传入的轨迹数据进行移动，此方法为相对移动。
    // offsets : 偏移列表。
    // sleep   : 每个点之间的延迟。
    API(Result) Trace(const std::vector<Offset<int16_t>> &offsets, uint32_t sleep=16);


  //                                                                     //
  // ----------------------------- 其他 API ----------------------------- //
  //                                                                     //

    // 取设备类型
    API(Result) GetDeviceType(DeviceType &type);

    // 设置超时。
    // 设置通讯超时，当发送命令到设备后，等待时间超过此时间时，返回 Result::Timeout。
    API(Result) SetTimeout(uint32_t timeout);

    // 取系统错误。
    // 在返回 Result::kSystemError 后调用，返回 windows api 的错误码。
    API(uint32_t) GetSystemError();

  private:
    HANDLE m_device_handle = INVALID_HANDLE_VALUE;

    uint16_t m_target_resolution_x;
    uint16_t m_target_resolution_y;

    std::default_random_engine m_random_engine;

    std::mutex m_mutex;

    uint32_t m_timeout = 2000;

    uint32_t m_system_error = ERROR_SUCCESS;

    bool m_is_reset = false;

    MouseMode m_mouse_mode = static_cast<MouseMode>(-1);
    DeviceType m_device_type = static_cast<DeviceType>(-1);

    Offset<uint16_t> m_cursor;

    #if RX78CPP_EXPORTS
    #include "private.inc.h"
    #endif
  };
}
